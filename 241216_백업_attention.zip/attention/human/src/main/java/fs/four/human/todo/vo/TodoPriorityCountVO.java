package fs.four.human.todo.vo;

import lombok.Data;
@Data
public class TodoPriorityCountVO {



}
