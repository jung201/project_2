package fs.four.human.alarm.controller;

public class AlarmController {
}
